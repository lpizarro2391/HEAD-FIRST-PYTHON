from setuptools import setup

setup(
    name='vsearh',
    version='1.0',
    description='The head First Python Search Tools',
    author='HF Python 2e',
    author_email='lourdespizarro@gmail.com',
    url='headfirstlabs.com',
    py_modules=['vsearch'],
)
